<?php

fscanf(STDIN, "%d %d", $a, $b);

// Implémentez votre algorithme entre les lignes ci-dessous.
// (vous pouvez néanmoins tout modifier si vous le désirez)
// Implementeer jouw algoritme tussen de lijnen hieronder.
// (al mag je wel alles aanpassen, als je dat wil)
// ------------------------------------------------------------------

$sum=$b+$b;

// ------------------------------------------------------------------

printf("%d\n", $sum);

?>
