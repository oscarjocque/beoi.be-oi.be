# -*- coding: utf8 -*-
from sys import stdin

a, b = map(int,stdin.readline().split())

# Implémentez votre algorithme entre les lignes ci-dessous.
# (vous pouvez néanmoins tout modifier si vous le désirez)
# Implementeer jouw algoritme tussen de lijnen hieronder.
# (al mag je wel alles aanpassen, als je dat wil)
# ------------------------------------------------------------------

sum = b+b

# ------------------------------------------------------------------

print "%d" % sum
