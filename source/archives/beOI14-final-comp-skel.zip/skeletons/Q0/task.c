#include <unistd.h>
#include <stdio.h>

int
main (int argc, char **argv)
{
    int a, b;
    scanf("%d %d", &a, &b);

    // Implémentez votre algorithme entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez)
    // Implementeer jouw algoritme tussen de lijnen hieronder.
    // (al mag je wel alles aanpassen, als je dat wil)
    // ------------------------------------------------------------------

    int sum = b+b;

    // ------------------------------------------------------------------

    printf("%d\n", sum);
    return 0;
}
