#include <iostream>
#include <string>

using namespace std;

int main (int argc, char* const *argv)
{
    int a, b;
    scanf("%d %d", &a, &b);

    // Implémentez votre algorithme entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez)
    // Implementeer jouw algoritme tussen de lijnen hieronder.
    // (al mag je wel alles aanpassen, als je dat wil)
    // ------------------------------------------------------------------

    int sum = b+b;

    // ------------------------------------------------------------------

    std::cout << sum << std::endl;
    return 0;
}
