                                                                                                                                                                                                          
import java.io.BufferedInputStream;                                                                                                                                                                        
import java.io.IOException;                                                                                                                                                                                
import java.io.InputStream;                                                                                                                                                                                
import java.util.InputMismatchException;                                                                                                                                                                   
import java.util.NoSuchElementException;                                                                                                                                                                   
import java.lang.Character;                                                                                                                                                                                
           
// Quelques remarques liées à l'utilisation de Java:
//  - Le nom de la classe DOIT rester "Task" pour compiler sur le serveur de
//    soumissions.
//  - Vous remarquerez que la classe Scanner de Java a été remplacée par 
//    implémentation spécifique. Il s'agit là d'une modification permettant 
//    d'éviter un problème d'efficacité du compilateur GCJ. Nous vous 
//    conseillons donc fortement d'utiliser l'implémentation que nous vous
//    proposons. 
// Enkele opmerkingen bij het gebruik van Java:
// - De naam van de klasse MOET "Task" blijven om te kunnen compileren op de beoordelings-server.
// - Je merkt dat de klasse Scanner van Java werd vervangen door een eigen specifieke implementatie.
//    Die bevat een aanpassing die nodig is om een efficiëntieprobleem van de GCJ compiler te omzeilen.
//    We raden je dus sterk aan om onze implementatie te blijven gebruiken.


public class Task {

   static public class Scanner {
      private BufferedInputStream in; int c; boolean atStartOfLine;
      public Scanner(InputStream stream) {
         in = new BufferedInputStream(stream);
         try { atStartOfLine = true; c  = (char)in.read(); } catch (IOException e) { c  = -1; }
      }
      public String next() {
         StringBuffer sb = new StringBuffer();
         atStartOfLine = false;
         try {
            while (c <= ' ') {c = in.read();if (c == -1)throw new NoSuchElementException();} 
            while (c > ' ') {sb.append((char)c);c = in.read();}
            while (Character.isWhitespace(c)) {c = in.read(); if (c == -1) break; } 
         } catch (IOException e) { c = -1; return ""; }
         return sb.toString();
      }
      public int nextInt() {
         String s = next();
         try { return Integer.parseInt(s); } catch (NumberFormatException e) { throw new InputMismatchException(); }
      }
   }

   public static void main(String args[]) {

        Scanner scanner = new Scanner(System.in);
        
        int N = scanner.nextInt();

        int[] L = new int[N];
        for(int i = 0; i < N; i++){
            L[i] = scanner.nextInt();
        }
        
        // Implémentez votre algorithme entre les lignes ci-dessous.
        // (vous pouvez néanmoins tout modifier si vous le désirez) 
        // Implementeer jouw algoritme tussen de lijnen hieronder.
        // (al mag je wel alles aanpassen, als je dat wil)    
        // ------------------------------------------------------------------

        long result = 0;
        for (int i = 0; i < N; i++)
        {
          result += L[i];
        }

        System.out.println(result);

        // ------------------------------------------------------------------
    }


}
