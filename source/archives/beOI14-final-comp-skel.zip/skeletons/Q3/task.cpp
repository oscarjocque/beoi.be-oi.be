#include <iostream>
#include <string>

using namespace std;

int main (int argc, char* const *argv)
{
    int N;
    scanf("%d\n", &N);

    int L[N];
    for(int i = 0; i < N; i++) scanf("%d\n", &L[i]);

    // Implémentez votre algorithme entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez)
    // Implementeer jouw algoritme tussen de lijnen hieronder.
    // (al mag je wel alles aanpassen, als je dat wil)
    // ------------------------------------------------------------------

    long long result = 0;  
    for (int i = 0; i < N; i++)
    {
        result += L[i];
    }

    std::cout << result << std::endl;

    // ------------------------------------------------------------------

    return 0;
}
