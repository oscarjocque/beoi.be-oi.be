<?php

$N = intval(rtrim(fgets(STDIN), "\n"));
$L = array_fill(0, $N, 0);
for ($i = 0; $i < $N; $i++)
    $L[$i] = intval(fgets(STDIN));

// Implémentez votre algorithme entre les lignes ci-dessous.
// (vous pouvez néanmoins tout modifier si vous le désirez) 
// Implementeer jouw algoritme tussen de lijnen hieronder.
// (al mag je wel alles aanpassen, als je dat wil)    
// ------------------------------------------------------------------

$result = 0;
for ($i = 0; $i < $N; $i++)
{
	$result += $L[$i];
}

echo $result,"\n";

// ------------------------------------------------------------------

?>
