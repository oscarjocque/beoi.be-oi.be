#include <stdlib.h>
#include <stdio.h>

int main() {

    int N, i;
    scanf("%d\n", &N);

    int L[N];
    for(i = 0; i < N; i++) scanf("%d\n", &L[i]);

    // Implémentez votre algorithme entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Implementeer jouw algoritme tussen de lijnen hieronder.
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------

    long long result = 0;  
    for (i = 0; i < N; i++)
    {
        result += L[i];
    }

    printf("%lld\n", result);

    // ------------------------------------------------------------------

    return 0;
}
