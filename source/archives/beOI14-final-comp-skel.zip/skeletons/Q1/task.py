# -*- coding: utf8 -*-
import sys

[N, H] = map(int, raw_input().split())
T = [0] * N
for i in xrange(N): T[i] = int(raw_input())

# Implémentez votre algorithme entre les lignes ci-dessous.
# (vous pouvez néanmoins tout modifier si vous le désirez) 
# Implementeer jouw algoritme tussen de lijnen hieronder.
# (al mag je wel alles aanpassen, als je dat wil)    
# ------------------------------------------------------------------
  
result = H
for i in xrange(N):
	result = result + T[i]

print '%d' % result

# ------------------------------------------------------------------

