#include <stdlib.h>
#include <stdio.h>

int main() {

    int N, H, i;
    
    scanf("%d %d\n", &N, &H);

    int T[N];
    for(i = 0; i < N; i++){
       scanf("%d\n", &T[i]);
    }

    // Implémentez votre algorithme entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Implementeer jouw algoritme tussen de lijnen hieronder.
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------

    int result = H;
    for (i = 0; i < N; i++)
    {
        result += T[i];
    }

    printf("%d\n", result);

    // ------------------------------------------------------------------

    return 0;
}
