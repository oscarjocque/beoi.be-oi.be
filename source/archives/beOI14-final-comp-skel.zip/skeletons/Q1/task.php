<?php

list ($N, $H) = sscanf(rtrim(fgets(STDIN), "\n"), "%d %d");

$T = array_fill(0, $N, 0);
for ($i = 0; $i < $N; $i++)
    $T[$i] = intval(fgets(STDIN));

// Implémentez votre algorithme entre les lignes ci-dessous.
// (vous pouvez néanmoins tout modifier si vous le désirez) 
// Implementeer jouw algoritme tussen de lijnen hieronder.
// (al mag je wel alles aanpassen, als je dat wil)    
// ------------------------------------------------------------------

$result = $H;
for ($i = 0; $i < $N; $i++)
{
	$result += $T[$i];
}

echo $result,"\n";

// ------------------------------------------------------------------

?>
