#include <iostream>
#include <string>

using namespace std;

int main (int argc, char* const *argv)
{
    int N;
    scanf("%d", &N);

    int x[N];
    int a[N];
    int b[N];
    int p[N]; 

    for (int i = 0; i < N; i++)
        scanf("%d %d %d %d", &x[i], &a[i], &b[i], &p[i]);

    // Implémentez votre algorithme entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez)
    // Implementeer jouw algoritme tussen de lijnen hieronder.
    // (al mag je wel alles aanpassen, als je dat wil)
    // ------------------------------------------------------------------

    int result = 0;
    for (int i = 0; i < N; i++)
    {
        result += x[i] + b[i] - a[i] + p[i];
    }

    std::cout << result << std::endl;

    // ------------------------------------------------------------------

    return 0;
}
