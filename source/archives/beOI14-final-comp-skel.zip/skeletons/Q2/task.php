<?php

$N = intval(rtrim(fgets(STDIN), "\n"));
$x = array_fill(0, $N, 0);
$a = array_fill(0, $N, 0);
$b = array_fill(0, $N, 0);
$p = array_fill(0, $N, 0);

for ($i = 0; $i < $N; $i++) {
    list ($x[$i], $a[$i], $b[$i], $p[$i]) = sscanf(rtrim(fgets(STDIN), "\n"), "%d %d %d %d");
}

// Implémentez votre algorithme entre les lignes ci-dessous.
// (vous pouvez néanmoins tout modifier si vous le désirez) 
// Implementeer jouw algoritme tussen de lijnen hieronder.
// (al mag je wel alles aanpassen, als je dat wil)    
// ------------------------------------------------------------------

$result = 0;
for ($i = 0; $i < $N; $i++)
{
    $result += $x[$i] + $b[$i] - $a[$i] + $p[$i];
}
echo $result,"\n";

// ------------------------------------------------------------------

?>
