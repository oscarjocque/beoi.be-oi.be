# -*- coding: utf8 -*-
import sys

N = int(raw_input())
x = [0] * N
a = [0] * N
b = [0] * N
p = [0] * N
for n in xrange(N): 
    line = [int(i) for i in raw_input().split()]
    x[n], a[n], b[n], p[n] = line

# Implémentez votre algorithme entre les lignes ci-dessous.
# (vous pouvez néanmoins tout modifier si vous le désirez) 
# Implementeer jouw algoritme tussen de lijnen hieronder.
# (al mag je wel alles aanpassen, als je dat wil)    
# ------------------------------------------------------------------
  
result = 0
for i in xrange(N):
    result += x[i] + b[i] - a[i] + p[i]

print '%d' % result

# ------------------------------------------------------------------

