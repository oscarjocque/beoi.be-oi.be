<?php
ini_set('memory_limit', '512M');
ini_set('error_reporting', E_ALL);
if (PHP_INT_SIZE < 8) {
    die('Script available only on x64');
}

define('MAX_N', 500001);
define('MAX_R', 710);

global $N, $x, $a, $b, $p, $cache, $blocksize, $max_range, $max_individual;
$x = array_fill(0, MAX_N, 0);
$a = array_fill(0, MAX_N, 0);
$b = array_fill(0, MAX_N, 0);
$p = array_fill(0, MAX_N, 0);
$cache = array_fill(0, MAX_N, 0);
$blocksize = intval(floor(sqrt(500000)));
$max_range = array_fill(0, MAX_R, 0);
$max_individual = array_fill(0, MAX_N, 0);
$best = 0;

function update($which) {
    global $x, $cache, $blocksize, $max_range, $max_individual;
    $mr_idx = intval(floor($x[$which] / $blocksize));
    $max_range[$mr_idx] = max($cache[$which], $max_range[$mr_idx]);
    $max_individual[$x[$which]] = max($cache[$which], $max_individual[$x[$which]]);
}

function query($qs, $qe) {
    global $blocksize, $max_range, $max_individual;
    $best = 0;
    $qs_div_bs = intval(floor($qs / $blocksize)); 
    $qs_mod_bs = $qs % $blocksize;
    $qe_div_bs = intval(floor($qe / $blocksize)); 
    $qe_mod_bs = $qe % $blocksize;
    for ($i = $qs_div_bs + 1; $i < $qe_div_bs; $i++) $best = max($best, $max_range[$i]);
    if ($qs_div_bs != $qe_div_bs) {
        for ($i = $qs_mod_bs; $i < $blocksize; $i++) $best = max($best, $max_individual[$qs - $qs_mod_bs + $i]);
        for ($i = 0; $i <= $qe_mod_bs; $i++) $best = max($best, $max_individual[$qe - $qe_mod_bs + $i]);
    } else {
        for ($i = $qs; $i <= $qe; $i++) $best = max($best, $max_individual[$i]);
    }
    return $best;
}

function get_best($current) {
    global $a, $b, $p;
    $best = query($a[$current], $b[$current]);
    return $best + $p[$current];
}

$N = intval(rtrim(fgets(STDIN), "\n"));
for ($i = 0; $i < $N; $i++) {
    list ($x[$i], $a[$i], $b[$i], $p[$i]) = sscanf(rtrim(fgets(STDIN), "\n"), "%d %d %d %d");
}
for ($i = 0; $i < $N; $i++) {
    $cache[$i] = get_best($i);
    update($i);
    if ($cache[$i] > $best) $best = $cache[$i];
}
printf("%d\n", $best);
