#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

int n;
int x[500001];
int a[500001];
int b[500001];
int p[500001]; //p = prettyness
long long cache[500001];

//Maximum by block
int blocksize;
long long max_range[710];
long long max_individual[500001];

void update(int which) //inserts a value into the "root N blocks of root N" data structure
{
     max_range[x[which]/blocksize] = max(cache[which], max_range[x[which]/blocksize]);
     max_individual[x[which]] = max(cache[which], max_individual[x[which]]);
}

long long query(int start, int end) //query the data structure to find best value within range
{
     long long best = 0;
     int i;
     for (i = start/blocksize + 1; i < end/blocksize; i++)
         best = max(best, max_range[i]);
     if (start/blocksize != end/blocksize)
     {
         for (i = start % blocksize; i < blocksize; i++)
              best = max(best, max_individual[start - (start % blocksize) + i]);
         for (i = 0; i <= end % blocksize; i++)
              best = max(best, max_individual[end - (end % blocksize) + i]);
     }
     else
     {
         for (i = start; i <= end; i++)
             best = max(best, max_individual[i]);
     }
     return best;
}

long long get_best(int current) //if current firework is used, what is the value of the best set of fireworks that could have gone off before it
{
    int i;
    long long best = query(a[current], b[current]);
    return best + p[current];
}

int main()
{
    scanf("%d", &n);
    blocksize = sqrt(500000);
    int i;
    for (i = 0; i < n; i++)
        scanf("%d %d %d %d", &x[i], &a[i], &b[i], &p[i]);
    long long best = 0;
    for (i = 0; i < n; i++)
    {
        cache[i] = get_best(i);
        update(i);
        if (cache[i] > best)
           best = cache[i];
    }
    printf("%lld\n", best);
}
