# -*- coding: utf8 -*-
import sys, math

MAX_N = 500001
MAX_R = 710
N = int(raw_input())
x = [0] * MAX_N
a = [0] * MAX_N
b = [0] * MAX_N
p = [0] * MAX_N
cache = [0] * MAX_N
blocksize = int(math.floor(math.sqrt(500000)))
max_range = [0] * MAX_R
max_individual = [0] * MAX_N

def update(which):
    mr_idx = int(math.floor(x[which] / blocksize))
    max_range[mr_idx] = max(cache[which], max_range[mr_idx])
    max_individual[x[which]] = max(cache[which], max_individual[x[which]])

def query(qs, qe):
    best = 0
    qs_div_bs = int(math.floor(qs / blocksize))
    qs_mod_bs = qs % blocksize
    qe_div_bs = int(math.floor(qe / blocksize))
    qe_mod_bs = qe % blocksize
    for i in xrange(qs_div_bs + 1, qe_div_bs): best = max(best, max_range[i])
    if (qs_div_bs != qe_div_bs):
        for i in xrange(qs_mod_bs, blocksize): best = max(best, max_individual[qs - qs_mod_bs + i])
        for i in xrange(0, qe_mod_bs + 1): best = max(best, max_individual[qe - qe_mod_bs + i])
    else:
        for i in xrange(qs, qe + 1): best = max(best, max_individual[i])
    return best

def get_best(current):
    best = query(a[current], b[current])
    return best + p[current]

if __name__ == '__main__':
    best = 0
    for l in xrange(N):
        line = [int(i) for i in raw_input().split()]
        if len(line) == 0: continue
        x[l], a[l], b[l], p[l] = line
    for i in xrange(N):
        cache[i] = get_best(i)
        update(i)
        if (cache[i] > best):
           best = cache[i]
    print best
