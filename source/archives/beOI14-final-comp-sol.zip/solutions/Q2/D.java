                                                                                                                                                                                                          
import java.io.BufferedInputStream;                                                                                                                                                                        
import java.io.IOException;                                                                                                                                                                                
import java.io.InputStream;                                                                                                                                                                                
import java.util.InputMismatchException;                                                                                                                                                                   
import java.util.NoSuchElementException;                                                                                                                                                                   
import java.lang.Character;                                                                                                                                                                                
                                                                                                                                                                                                    
public class Task {

  static public class Scanner {
    private BufferedInputStream in; int c; boolean atStartOfLine;
    public Scanner(InputStream stream) {
       in = new BufferedInputStream(stream);
       try { atStartOfLine = true; c  = (char)in.read(); } catch (IOException e) { c  = -1; }
    }
    public String next() {
       StringBuffer sb = new StringBuffer();
       atStartOfLine = false;
       try {
          while (c <= ' ') {c = in.read();if (c == -1)throw new NoSuchElementException();} 
          while (c > ' ') {sb.append((char)c);c = in.read();}
          while (Character.isWhitespace(c)) {c = in.read(); if (c == -1) break; } 
       } catch (IOException e) { c = -1; return ""; }
       return sb.toString();
    }
    public int nextInt() {
       String s = next();
       try { return Integer.parseInt(s); } catch (NumberFormatException e) { throw new InputMismatchException(); }
    }
  }

  public static void main(String args[]) {

    Scanner scanner = new Scanner(System.in);
    
    int N = scanner.nextInt();
    int[] tab_x = new int[N];
    int[] tab_a = new int[N];
    int[] tab_b = new int[N];
    int[] tab_p = new int[N];

    for(int i = 0; i < N; i++)
    {
      tab_x[i] = scanner.nextInt();
      tab_a[i] = scanner.nextInt();
      tab_b[i] = scanner.nextInt();
      tab_p[i] = scanner.nextInt();
    }

    // Modifiez le code entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Pas de code aan die hieronder tussen de horizontale lijnen staat
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    long[] cache = new long[500001];
    int blocksize = (int)Math.sqrt(500000);
    long[] max_range = new long[710];
    long[] max_individual = new long[500001];

    long best = 0;
    for (int i = 0; i < N; i++)
    {
        int start = tab_a[i];
        int end = tab_b[i];

        long besti = 0;
         for (int j = start/blocksize + 1; j < end/blocksize; j++)
             besti = Math.max(besti, max_range[j]);
         if (start/blocksize != end/blocksize)
         {
             for (int j = start % blocksize; j < blocksize; j++)
                  besti = Math.max(besti, max_individual[start - (start % blocksize) + j]);
             for (int j = 0; j <= end % blocksize; j++)
                  besti = Math.max(besti, max_individual[end - (end % blocksize) + j]);
         }
         else
         {
             for (int j = start; j <= end; j++)
                 besti = Math.max(besti, max_individual[j]);
         }

        cache[i] = besti + tab_p[i];

        max_range[tab_x[i]/blocksize] = Math.max(cache[i], max_range[tab_x[i]/blocksize]);
        max_individual[tab_x[i]] = Math.max(cache[i], max_individual[tab_x[i]]);

        if (cache[i] > best)
           best = cache[i];
    }




    System.out.println(best);

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
  }

}
