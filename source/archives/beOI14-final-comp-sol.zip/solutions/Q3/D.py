# -*- coding: utf8 -*-
import sys, math

def get_partial_sum(s_from, s_to, cumsum):
    return cumsum[s_to + 1] - cumsum[s_from]

def solve(N, a):
    cumsum = [0] * (len(a)+1)
    right_ends_of_good_parts = [0] * len(a)
    for i in xrange(0, N):
      cumsum[i + 1] = cumsum[i] + a[i]
    total = get_partial_sum(0, N-1, cumsum)
    if (total % 2) == 1: return 0
    left_index = 0
    right_index = 0
    best = 0
    half_parts_amount = 0
    while right_index < N:
        curr_sum = get_partial_sum(left_index, right_index, cumsum)
        if curr_sum < (total/2):
            right_index = right_index + 1
        elif curr_sum > (total/2):
            left_index = left_index + 1
        elif curr_sum == (total/2):
            left = 0
            right = half_parts_amount - 1
            while left <= right:
                mid = (left + right) / 2
                corner_index = right_ends_of_good_parts[mid]
                side1 = get_partial_sum(left_index, corner_index, cumsum)
                side2 = total/2 - side1
                best = max(side1 * side2, best)
                if side1 < side2:
                    left = mid+1
                elif side2 < side1:
                    right = mid-1
                else:
                    return best
            right_ends_of_good_parts[half_parts_amount] = right_index
            half_parts_amount = half_parts_amount + 1
            left_index = left_index + 1
            right_index = right_index + 1
    return best

if __name__ == '__main__':
    N = int(raw_input())
    a = [int(raw_input()) for _ in range(N)]
    print solve(N, a)
