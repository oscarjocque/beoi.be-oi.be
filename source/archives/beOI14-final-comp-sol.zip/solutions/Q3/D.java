import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.lang.Character;

public class Task {
    
    static public class Scanner {
        private BufferedInputStream in; int c; boolean atStartOfLine;
        public Scanner(InputStream stream) {
            in = new BufferedInputStream(stream);
            try { atStartOfLine = true; c  = (char)in.read(); } catch (IOException e) { c  = -1; }
        }
        public String next() {
            StringBuffer sb = new StringBuffer();
            atStartOfLine = false;
            try {
                while (c <= ' ') {c = in.read();if (c == -1)throw new NoSuchElementException();} 
                while (c > ' ') {sb.append((char)c);c = in.read();}
                while (Character.isWhitespace(c)) {c = in.read(); if (c == -1) break; } 
            } catch (IOException e) { c = -1; return ""; }
            return sb.toString();
        }
        public int nextInt() {
            String s = next();
            try { return Integer.parseInt(s); } catch (NumberFormatException e) { throw new InputMismatchException(); }
        }
    }
    
    
    static long get_partial_sum(int from, int to, long[] a, long[] cumsum) {
        return cumsum[to+1] - cumsum[from];
    }
    static long solve(int N, long[] a, long[] cumsum) {
        int[] right_ends_of_good_parts = new int[N];
        int half_parts_amount;
        for(int i = 0; i < N; ++i) {
            cumsum[i+1] = cumsum[i] + a[i];
        }
        long total = get_partial_sum(0, N-1, a, cumsum);
        if(total%2 == 1)
            return 0;
        //find a set of consecutive elements in a summing up to (the total sum of a)/2
        int left_index = 0;
        int right_index = 0;
        long best = 0;
        half_parts_amount = 0;
        while (right_index<N) {
            long curr_sum = get_partial_sum(left_index, right_index, a, cumsum);
            if(curr_sum < total/2){
                ++right_index;
            }else if(curr_sum > total/2){
                ++left_index;
            }else if(curr_sum == total/2){
                //Binary search on previously found partial sums, find corner!
                int left = 0;
                int right = half_parts_amount-1;
                while(left <= right){
                    int mid = (left+right)/2;
                    int corner_index = right_ends_of_good_parts[mid];
                    long side1 = get_partial_sum(left_index, corner_index, a, cumsum);
                    long side2 = total/2-side1;
                    best = Math.max(side1*side2, best);
                    if(side1 < side2){
                        left = mid+1;
                    }else if(side2 < side1){
                        right = mid-1;
                    }else{
                        return best;
                    }
                }
                right_ends_of_good_parts[half_parts_amount] = right_index;
                ++half_parts_amount;
                ++left_index;
                ++right_index;
            }
        }
        return best;
    }
  
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        long[] a =  new long[n];
        long[] cumsum = new long[n+1];
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }
        System.out.println(solve(n, a, cumsum));
    }

}
