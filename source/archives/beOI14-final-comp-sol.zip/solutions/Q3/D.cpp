#include <cstdio>
#define MAX_N 1000000
long long a[MAX_N];
long long solve(int N, long long *a);
int main(){
//	int T;
//	scanf("%d", &T);
//	while(T--){
		int N;
		scanf("%d", &N);
		for(int i = 0; i <N; ++i){
			scanf("%lld", &a[i]);
		}
		printf("%lld\n", solve(N, a));
//	}
	return 0;
}


//SOLUTION
//O(N*log(N))

long long cumsum[MAX_N+1];
inline long long get_partial_sum(int from, int to){
	return cumsum[to+1]-cumsum[from];
}
inline long long max(long long a, long long b){
	return a>b?a:b;
}
int right_ends_of_good_parts[MAX_N];
int half_parts_amount;

long long solve(int N, long long *a){
	for(int i = 0; i < N; ++i){
		cumsum[i+1]=cumsum[i]+a[i];
	}
	long long total = get_partial_sum(0, N-1);
	if(total%2 == 1)
		return 0;
	//find a set of consecutive elements in a summing up to (the total sum of a)/2
	int left_index = 0;
	int right_index = 0;
	long long best = 0;
	half_parts_amount = 0;
	while(right_index<N){
		long long curr_sum = get_partial_sum(left_index, right_index);
		if(curr_sum < total/2){
			++right_index;
		}else if(curr_sum > total/2){
			++left_index;
		}else if(curr_sum == total/2){
			//Binary search on previously found partial sums, find corner!
			int left = 0;
			int right = half_parts_amount-1;
			while(left <= right){
				int mid = (left+right)/2;
				int corner_index = right_ends_of_good_parts[mid];
				long long side1 = get_partial_sum(left_index, corner_index);
				long long side2 = total/2-side1;
				best = max(side1*side2, best);
				if(side1 < side2){
					left = mid+1;
				}else if(side2 < side1){
					right = mid-1;
				}else{
					return best;
				}
			}
			right_ends_of_good_parts[half_parts_amount] = right_index;
			++half_parts_amount;
			++left_index;
			++right_index;
		}
	}
	return best;
}
