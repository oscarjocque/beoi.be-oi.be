<?php
ini_set('memory_limit', '1024M');
ini_set('error_reporting', E_ALL);
if (PHP_INT_SIZE < 8) {
    die('Script available only on x64');
}

function get_partial_sum($from, $to, $cumsum) {
    return $cumsum[$to + 1] - $cumsum[$from];
}

function solve($N, $a) {
    $cumsum = array_fill(0, count($a) + 1, 0);
    $right_ends_of_good_parts = array_fill(0, count($a), 0);
    for($i = 0; $i < $N; ++$i){
      $cumsum[$i + 1] = $cumsum[$i] + $a[$i];
    }
    $total = get_partial_sum(0, $N-1, $cumsum);
    if($total%2 == 1) return 0;
    $left_index = 0;
    $right_index = 0;
    $best = 0;
    $half_parts_amount = 0;
    while ($right_index<$N) {
        $curr_sum = get_partial_sum($left_index, $right_index, $cumsum);
        if ($curr_sum < $total/2) {
            ++$right_index;
        } else if ($curr_sum > $total/2) {
            ++$left_index;
        } else if ($curr_sum == $total/2) {
            $left = 0;
            $right = $half_parts_amount - 1;
            while (!($left > $right)) {
                $mid = floor(($left + $right)/2);
                $corner_index = $right_ends_of_good_parts[$mid];
                $side1 = get_partial_sum($left_index, $corner_index, $cumsum);
                $side2 = $total/2 - $side1;
                $best = max($side1*$side2, $best);
                if ($side1 < $side2) {
                    $left = $mid+1;
                } else if ($side2 < $side1) {
                    $right = $mid-1;
                } else{
                    return $best;
                }
            }
            $right_ends_of_good_parts[$half_parts_amount] = $right_index;
            ++$half_parts_amount;
            ++$left_index;
            ++$right_index;
        }
    }
    return $best;
}

$N = intval(rtrim(fgets(STDIN), "\n"));
//$a = array_map('intval', explode(' ', trim(fgets(STDIN))));
$a = array($N);
for($i = 0; $i < $N; ++$i){
	$a[$i]=intval(rtrim(fgets(STDIN), "\n"));
}
printf("%d\n", solve($N, $a));
