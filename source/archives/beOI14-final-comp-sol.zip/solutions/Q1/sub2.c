#include <stdlib.h>
#include <stdio.h>

int main() {

    int i = 0;

    int N, H;
    
    scanf("%d %d\n", &N, &H);

    int *tab = (int *) malloc( N * sizeof(int) );
    for( i = 0; i < N; i++){
       scanf("%d\n", &tab[i]);
    }

    // Modifiez le code entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Pas de code aan die hieronder tussen de horizontale lijnen staat
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
        
    int max_length = 0, sub_length = 0;

    for (i = 0; i < N; i++)
    {
        if (tab[i] >= H)
        {
            sub_length += 1;
        }
        else
        {
            if (sub_length > max_length) max_length = sub_length;
            sub_length = 0;
        }
    }
    if (sub_length > max_length) max_length = sub_length;
    printf("%d\n", max_length);

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    return 0;
}
