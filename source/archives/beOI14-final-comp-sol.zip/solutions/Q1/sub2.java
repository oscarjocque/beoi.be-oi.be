                                                                                                                                                                                                          
import java.io.BufferedInputStream;                                                                                                                                                                        
import java.io.IOException;                                                                                                                                                                                
import java.io.InputStream;                                                                                                                                                                                
import java.util.InputMismatchException;                                                                                                                                                                   
import java.util.NoSuchElementException;                                                                                                                                                                   
import java.lang.Character;                                                                                                                                                                                
                                                                                                                                                                                                    
public class Task {

   static public class Scanner {
      private BufferedInputStream in; int c; boolean atStartOfLine;
      public Scanner(InputStream stream) {
         in = new BufferedInputStream(stream);
         try { atStartOfLine = true; c  = (char)in.read(); } catch (IOException e) { c  = -1; }
      }
      public String next() {
         StringBuffer sb = new StringBuffer();
         atStartOfLine = false;
         try {
            while (c <= ' ') {c = in.read();if (c == -1)throw new NoSuchElementException();} 
            while (c > ' ') {sb.append((char)c);c = in.read();}
            while (Character.isWhitespace(c)) {c = in.read(); if (c == -1) break; } 
         } catch (IOException e) { c = -1; return ""; }
         return sb.toString();
      }
      public int nextInt() {
         String s = next();
         try { return Integer.parseInt(s); } catch (NumberFormatException e) { throw new InputMismatchException(); }
      }
   }

   public static void main(String args[]) {

        Scanner scanner = new Scanner(System.in);
        
        int N = scanner.nextInt();
        int H = scanner.nextInt();

        int[] tab = new int[N];
        for(int i = 0; i < N; i++){
            tab[i] = scanner.nextInt();
        }
        
        // Modifiez le code entre les lignes ci-dessous.
        // (vous pouvez néanmoins tout modifier si vous le désirez) 
        // Pas de code aan die hieronder tussen de horizontale lijnen staat
        // (al mag je wel alles aanpassen, als je dat wil)    
        // ------------------------------------------------------------------
        // ------------------------------------------------------------------

        int max_length = 0, sub_length = 0;

        for (int i = 0; i < N; i++)
        {
            if (tab[i] >= H)
            {
                sub_length += 1;
            }
            else
            {
                if (sub_length > max_length) max_length = sub_length;
                sub_length = 0;
            }
        }
        if (sub_length > max_length) max_length = sub_length;

        System.out.println(max_length);

        // ------------------------------------------------------------------
        // ------------------------------------------------------------------
    }


}
