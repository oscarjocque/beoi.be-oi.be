# -*- coding: utf8 -*-
import sys

[N, H] = map(int, raw_input().split())
tab_n = [int(raw_input().split()[0]) for _ in xrange(N)]

# Modifiez le code entre les lignes ci-dessous.
# (vous pouvez néanmoins tout modifier si vous le désirez) 
# Pas de code aan die hieronder tussen de horizontale lijnen staat
# (al mag je wel alles aanpassen, als je dat wil)    
# ------------------------------------------------------------------
# ------------------------------------------------------------------
  
max_length = 0
sub_length = 0 

for i in xrange(N):

	if tab_n[i] >= H:
		sub_length += 1
	else:
		if sub_length > max_length: max_length = sub_length
		sub_length = 0

if sub_length > max_length: max_length = sub_length 
print '%d' % max_length

# ------------------------------------------------------------------
# ------------------------------------------------------------------

