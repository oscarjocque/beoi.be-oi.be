#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#define max(A,B) (((A) < (B))? (B): (A))

int main() {

    int i = 0;

    int n, t;
    int *tab;

    scanf("%d %d\n", &n, &t);
    tab = malloc( n * sizeof(int) );
    for( i=0; i<n; i++){
        scanf("%d\n", &tab[i]);
    }

    // Modifiez le code entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Pas de code aan die hieronder tussen de horizontale lijnen staat
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    t /= 5;
    
    i=1;
    int best = 0;
    int sum = tab[0];
    int val = 0;
    while ( i < n && i <= t ){
        sum += tab[i];

        val = sum;
        val += tab[i-1] * ((t-i)/2 + (t-i)%2);
        val += tab[i] * ((t-i)/2);

        best = max( best, val );
        i++;
    }
    
    printf("%d\n", best) ;

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    return 0;
}
