import java.util.Scanner;

public class Main {

    public static void main(String args[]) {

        Scanner scanner = new Scanner(System.in);
        int n, t;
        int tab[];

        n = scanner.nextInt();
        t = scanner.nextInt();

        tab = new int[n];
        for(int i = 0; i < n; i++){
            tab[i] = scanner.nextInt();
        }
        
        // Modifiez le code entre les lignes ci-dessous.
        // (vous pouvez néanmoins tout modifier si vous le désirez) 
        // Pas de code aan die hieronder tussen de horizontale lijnen staat
        // (al mag je wel alles aanpassen, als je dat wil)    
        // ------------------------------------------------------------------
        // ------------------------------------------------------------------
        
        System.out.println(tab[0]);

        // ------------------------------------------------------------------
        // ------------------------------------------------------------------
    }
}
