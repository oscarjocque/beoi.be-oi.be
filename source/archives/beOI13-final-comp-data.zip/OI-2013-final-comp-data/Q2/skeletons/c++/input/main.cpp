#include <iostream>
#include <vector>

int main() {

    int n, t;
    std::vector<int> tab;

    std::cin >> n >> t; 
    tab.resize(n);
    for(int i=0; i<n; i++){
        std::cin >> tab[i];
    }

    // Modifiez le code entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Pas de code aan die hieronder tussen de horizontale lijnen staat
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    std::cout << tab[0] << std::endl;

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    return 0;
}
