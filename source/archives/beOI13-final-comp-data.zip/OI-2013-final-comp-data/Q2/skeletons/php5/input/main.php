<?php

list($n, $t) = array_map("intval", explode(' ', fgets(STDIN)) );
$tab = array();
for ($_i = 0; $_i < $n; $_i++)
    $tab[] = intval(fgets(STDIN));

// Modifiez le code entre les lignes ci-dessous.
// (vous pouvez néanmoins tout modifier si vous le désirez) 
// Pas de code aan die hieronder tussen de horizontale lijnen staat
// (al mag je wel alles aanpassen, als je dat wil)    
// ------------------------------------------------------------------
// ------------------------------------------------------------------

echo $tab[0];

// ------------------------------------------------------------------
// ------------------------------------------------------------------

?>

