# -*- coding: utf8 -*-
import sys

n, t = tuple( int(i) for i in raw_input().split() )
tab = [ int(raw_input()) for _ in range(n) ]

# Modifiez le code entre les lignes ci-dessous.
# (vous pouvez néanmoins tout modifier si vous le désirez) 
# Pas de code aan die hieronder tussen de horizontale lijnen staat
# (al mag je wel alles aanpassen, als je dat wil)    
# ------------------------------------------------------------------
# ------------------------------------------------------------------

print tab[0]

# ------------------------------------------------------------------
# ------------------------------------------------------------------

