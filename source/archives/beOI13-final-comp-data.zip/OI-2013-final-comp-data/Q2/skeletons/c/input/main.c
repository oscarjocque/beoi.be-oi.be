#include <stdlib.h>
#include <stdio.h>

int main() {

    int i = 0;

    int n, t;
    int *tab;

    scanf("%d %d\n", &n, &t);
    tab = malloc( n * sizeof(int) );
    for( i=0; i<n; i++){
        scanf("%d\n", &tab[i]);
    }

    // Modifiez le code entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Pas de code aan die hieronder tussen de horizontale lijnen staat
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    printf("%d\n", tab[0]);

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    return 0;
}
