<?php

function f($n) {
    if ($n % 2 == 0) {
        return $n/2;
    }
    else {
      $x = ($n*$n) & 0xffffffff;
      if ($n > 1000) {
        $x = 5*$x - 3;
      }
      else {
        $x = 5*$x + 1;
      }
      $x = $x & 0xffffffff;
      if (($x & 0x80000000) != 0) {
        return $x - 0x100000000;
      } else {
        return $x;
      }
   }
}

$x = intval(fgets(STDIN));

// Modifiez le code entre les lignes ci-dessous.
// (vous pouvez néanmoins tout modifier si vous le désirez) 
// Pas de code aan die hieronder tussen de horizontale lijnen staat
// (al mag je wel alles aanpassen, als je dat wil)    
// ------------------------------------------------------------------
// ------------------------------------------------------------------

echo f(f($x));

// ------------------------------------------------------------------
// ------------------------------------------------------------------

?>

