#include <stdlib.h>
#include <stdio.h>

int f (int n) {
    if (n % 2 == 0) {
        return n/2;
    }
    else if (n > 1000) {
        return  5*n*n - 3;
    }
    else  {
        return 5*n*n + 1;
    }
}

int main() {

    int x;
    scanf("%d", &x);

    // Modifiez le code entre les lignes ci-dessous.
    // (vous pouvez néanmoins tout modifier si vous le désirez) 
    // Pas de code aan die hieronder tussen de horizontale lijnen staat
    // (al mag je wel alles aanpassen, als je dat wil)    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    printf("%d\n", f(f(x)));

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    return 0;
}
