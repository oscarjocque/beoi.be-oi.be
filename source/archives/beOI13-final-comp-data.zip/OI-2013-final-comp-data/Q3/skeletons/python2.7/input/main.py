# -*- coding: utf8 -*-
import sys

def f (n):
    if n % 2 == 0:
        return n/2
    else:
      if n > 1000:
        x = 5*n*n - 3
      else:
        x = 5*n*n + 1;
      x = x & 0xffffffff
      if x & 0x80000000:
        return x - 0x100000000
      else:
        return x

x = int(raw_input())

# Modifiez le code entre les lignes ci-dessous.
# (vous pouvez néanmoins tout modifier si vous le désirez) 
# Pas de code aan die hieronder tussen de horizontale lijnen staat
# (al mag je wel alles aanpassen, als je dat wil)    
# ------------------------------------------------------------------
# ------------------------------------------------------------------

print f(f(x))

# ------------------------------------------------------------------
# ------------------------------------------------------------------

